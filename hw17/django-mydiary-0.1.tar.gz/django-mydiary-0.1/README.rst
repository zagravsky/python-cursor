=====
My Diary
=====

A simple Django app for creating posts in the form of diary entries.


Quick start
-----------

1. Add "diary" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'diary',
    ]

2. Include the diary URLconf in your project urls.py like this::

    path('diary/', include('diary.urls')),

3. Run `python manage.py migrate` to create the polls models.

4. Start the development server

5. Visit http://127.0.0.1:8000/polls/ to use the site